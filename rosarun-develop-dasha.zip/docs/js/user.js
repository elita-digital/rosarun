"use strict";

var $offsetNav,
    rtime,
    $main = $("body");

function offsetNextBlock() {
  $offsetNav = .4 * $(window).height();
}

$(document).ready(function () {
  $("body").on("click", ".count-inputs a.pl", function (e) {
    e.preventDefault(), $(this).parent().find(".min").removeClass("disabled");
    var t = parseInt($(this).parent().find("input").val()) + 1;
    $(this).parent().find("input").val(t);
  }).on("click", ".count-inputs a.min", function (e) {
    event.preventDefault();
    var t = parseInt($(this).parent().find("input").val()) - 1;
    t < 2 && (t = 1, $(this).addClass("disabled")), $(this).parent().find("input").val(t);
  }).on("click", ".select-gender", function (e) {
    e.preventDefault(), $(this).find("span").toggleClass("active");
  }).on("click", function (e) {
    $(e.target).closest(".dropdown-menu").size() > 0 && e.stopImmediatePropagation();
  }).on("click", ".button-menu-wrap", function (e) {
    e.preventDefault(), $("body").toggleClass("menu-opened");
  }).on("click", ".fancybox", function (e) {
    e.preventDefault();
    var t = $(this).attr("href");
    $.fancybox.close(), $.fancybox.open({
      src: t,
      type: "ajax",
      afterShow: function afterShow() {
        $("[type='tel']").intlTelInput(), $(".datepicker").datepicker({
          format: "dd/mm/yyyy",
          language: "ru",
          autoclose: !0
        });
      }
    });
  }).on("click", ".gallery-hashtag a", function (e) {
    e.preventDefault(), $(".gallery-hashtag a").removeClass("active"), $(this).addClass("active"), $(".gallery-slider").slick("slickUnfilter").slick("slickFilter", $(this).attr("data-filter"));
  }).on("click", ".track-header a", function (e) {
    e.preventDefault(), $(".track-header a").removeClass("active"), $(this).addClass("active"), $(".track-slider").slick("slickUnfilter").slick("slickFilter", $(this).attr("data-filter"));
  }).on("click", ".food-header a", function (e) {
    e.preventDefault(), $(".food-header a").removeClass("active"), $(this).addClass("active"), $(".food-slider").slick("slickUnfilter").slick("slickFilter", $(this).attr("data-filter"));
  }).on("click", ".logo a", function (e) {
    e.preventDefault(), $("body").removeClass("menu-opened"), $(".main-wrap-wrap").animate({
      scrollTop: 0
    }, 1e3);
  }).on("click", ".wrap-icon a", function (e) {
    if (!$(this).hasClass("lk-enter")) {
      e.preventDefault();
      var t = $(this).attr("href");
      $("body").removeClass("menu-opened").scrollTo(t, 600);
    }
  }).on("click", ".scrollTo", function (e) {
    e.preventDefault();
    var t = $(this).attr("href");
    $("body").scrollTo(t, 600);
  }).on("click", ".shadow", function () {
    $("body").removeClass("menu-opened");
  }), $(".reg-slider").slick({
    dots: !1,
    arrows: !0,
    infinite: !1,
    autoplay: !1,
    speed: 400,
    slidesToShow: 1,
    slidesToScroll: 1,
    responsive: [{
      breakpoint: 600,
      settings: {
        arrows: !1,
        dots: !0
      }
    }]
  }), $(".program-slider").slick({
    dots: !1,
    arrows: !0,
    infinite: !1,
    autoplay: !1,
    speed: 400,
    slidesToShow: 2,
    slidesToScroll: 2,
    responsive: [{
      breakpoint: 900,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1
      }
    }, {
      breakpoint: 600,
      settings: {
        arrows: !1,
        slidesToShow: 1,
        slidesToScroll: 1,
        dots: !0
      }
    }]
  }), $(".food-slider").slick({
    dots: !1,
    arrows: !0,
    infinite: !1,
    autoplay: !1,
    speed: 400,
    slidesToShow: 3,
    slidesToScroll: 3,
    responsive: [{
      breakpoint: 1e3,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2
      }
    }, {
      breakpoint: 600,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1,
        arrows: !1,
        dots: !0
      }
    }]
  }), offsetNextBlock(), $main.scrollspy({
    target: ".scrollspy",
    offset: $offsetNav
  }), tableHead(), $(".chosen-select").chosen({
    disable_search_threshold: 10
  }), $("[type='tel']").intlTelInput(), $(".datepicker").datepicker({
    format: "dd/mm/yyyy",
    language: "ru"
  });
});
var timeout = !1,
    delta = 200;

function resizeend() {
  new Date() - rtime < delta ? setTimeout(resizeend, delta) : (timeout = !1, tableHead(), offsetNextBlock());
}

function tableHead() {
  Modernizr.touchevents && $(window).width() < 600 ? $(".fixTable").tableHeadFixer({
    head: !1,
    left: 0
  }) : $(".fixTable").tableHeadFixer({
    head: !0,
    left: 1
  });
}

$(window).resize(function () {
  rtime = new Date(), !1 === timeout && (timeout = !0, setTimeout(resizeend, delta));
});
var tabLinks = document.querySelectorAll(".main__tabs-link"),
    tabContent = document.querySelectorAll(".main__tabs-content");
if (tabLinks) for (var e = 0; e < tabLinks.length; e++) {
  tabLinks[e].addEventListener("click", function (e) {
    e.preventDefault();
    var t = e.target.getAttribute("data-tab");

    for (var _e = 0; _e < tabLinks.length; _e++) {
      t === tabContent[_e].getAttribute("data-tab-content") ? (tabContent[_e].classList.add("--active"), tabLinks[_e].classList.add("active")) : (tabContent[_e].classList.remove("--active"), tabLinks[_e].classList.remove("active"));
    }
  });
}
$(function () {
  $(".run-slider__inner").slick({
    prevArrow: '<button type="button" class="run-slider__slick-btn --slick-prev"><i class="icon-prev"></i></button>',
    nextArrow: '<button type="button" class="run-slider__slick-btn --slick-next"><i class="icon-next"></button>',
    slidesToShow: 1,
    slidesToScroll: 1,
    fade: !0
  }), $(".run-slider__nav").slick({
    slidesToShow: 5,
    slidesToScroll: 1,
    asNavFor: ".run-slider__inner",
    focusOnSelect: !0
  }), $(window).on("load resize orientationchange", function () {
    window.matchMedia("(max-width: 1023px)").matches ? $(".info__cards").slick({
      slidesToShow: 1,
      dots: !0,
      arrows: !1,
      centerMode: !0,
      centerPadding: "0"
    }) : $(".info__cards").slick("unslick");
  }), $(".header__burger").on("click", function () {
    $(".header__mobile").slideToggle(240);
  });
  var e = $(".info__cards").height();
  var t = ["01.05.2021", "02.05.2021", "03.05.2021", "04.05.2021", "04.05.2021", "04.05.2021"],
      i = ["ROSA\tPEAK", "ROSA QUEST", "ROSA CARNIVAL ", "ROSA GREEN TRAIL", "ROSA RED TRAIL ", "ROSA KIDS"];

  function n() {
    if (document.querySelector(".info__cards").getBoundingClientRect().top <= 0 && document.querySelector(".info__cards").getBoundingClientRect().top >= -e) return Math.round(($(".info__mountain").offset().top - $(".info__cards").offset().top) / (e / 6) - .5);
  }

  $(window).on("load scroll", function () {
    void 0 !== n() && ($(".js-change-date").text(t[n()]), $(".js-change-name").text(i[n()]));
  });
});
//# sourceMappingURL=../sourcemaps/user.js.map
